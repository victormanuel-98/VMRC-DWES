import { menu } from "../ui/menu.js";

export function iniciarApp() {
    menu();
}
